#include<stdio>
int main ()
{
    int i
}