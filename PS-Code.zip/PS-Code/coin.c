#include<stdio.h>
int main()
{
    int n;
    printf("Enter the vlaue of n: ");
    scanf("%d",&n);
    int term = 
}